// tambah-kost.js
document.addEventListener('DOMContentLoaded', function() {
    const tahunElement = document.getElementById('tahunSekarangTambahKost');
    if (tahunElement) {
        tahunElement.textContent = new Date().getFullYear();
    }

    // Fungsi untuk update label custom file input Bootstrap
    function updateFileLabel(fileInputId) {
        const fileInput = document.getElementById(fileInputId);
        if (fileInput) {
            fileInput.addEventListener('change', function(event) {
                const inputFile = event.target;
                const label = $(inputFile).next('.custom-file-label'); // jQuery untuk kemudahan
                let fileNameText = "Pilih file...";

                if (inputFile.files && inputFile.files.length > 1) {
                    fileNameText = `${inputFile.files.length} file dipilih`;
                } else if (inputFile.files && inputFile.files.length === 1) {
                    fileNameText = inputFile.files[0].name;
                }
                label.html(fileNameText);

                // Tambahan: Pratinjau gambar sederhana untuk foto utama
                if (fileInputId === 'fotoUtama' && inputFile.files && inputFile.files[0]) {
                    const previewContainer = document.getElementById('previewFotoTambahKost');
                    if (previewContainer) {
                        // Kosongkan preview lama jika ada untuk foto utama
                        const existingMainPreview = previewContainer.querySelector('img.main-preview');
                        if(existingMainPreview) existingMainPreview.remove();

                        const reader = new FileReader();
                        reader.onload = function(e) {
                            const img = document.createElement('img');
                            img.src = e.target.result;
                            img.style.maxWidth = '100px';
                            img.style.maxHeight = '100px';
                            img.style.margin = '5px';
                            img.classList.add('img-thumbnail', 'main-preview');
                            previewContainer.insertBefore(img, previewContainer.firstChild); // Tampilkan di awal
                        }
                        reader.readAsDataURL(inputFile.files[0]);
                    }
                }
                // Untuk fotoLainnya, pratinjau bisa lebih kompleks jika ingin menampilkan semua
            });
        }
    }

    updateFileLabel('fotoUtama');
    updateFileLabel('fotoLainnya');


    const form = document.getElementById('formTambahKostPage');
    if (form) {
        form.addEventListener('submit', function(event) {
            event.preventDefault();
            // Validasi form (bisa ditambahkan di sini)
            // ...

            const formData = new FormData(form);
            console.log("Data Form Tambah Kost:");
            for (let [key, value] of formData.entries()) {
                // Untuk file, value akan berupa objek File. Untuk checkbox fasilitas[], akan ada multiple entries.
                if (value instanceof File) {
                    console.log(`${key}: ${value.name} (type: ${value.type}, size: ${value.size} bytes)`);
                } else {
                    console.log(`${key}: ${value}`);
                }
            }

            alert('Kost disimulasikan untuk dipublikasikan! Cek console untuk data.');
            // Di sini Anda akan mengirimkan formData ke backend menggunakan fetch()
            // fetch('/api/owner/tambah-kost', {
            //    method: 'POST',
            //    body: formData
            // })
            // .then(response => response.json())
            // .then(data => { console.log(data); alert('Kost berhasil ditambahkan!'); })
            // .catch(error => { console.error(error); alert('Gagal menambahkan kost.'); });
        });
    }
});