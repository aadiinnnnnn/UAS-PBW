document.addEventListener('DOMContentLoaded', function() {
    // Set tahun sekarang di footer
    document.getElementById('tahunSekarang').textContent = new Date().getFullYear();

    // Data Kost (Contoh)
    const allKostData = [
        {
            id: 1,
            nama: 'Kost Mawar Melati Asri',
            tipe: 'Putri',
            lokasi: 'Jl. Kebahagiaan No. 12, Jakarta Selatan',
            harga: 1500000,
            fasilitas: ['AC', 'WiFi', 'Kamar Mandi Dalam'],
            gambar: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aG91c2UlMjBleHRlcmlvcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
            durasi: 'Bulanan'
        },
        {
            id: 2,
            nama: 'Kost Pria Idaman Sejahtera',
            tipe: 'Putra',
            lokasi: 'Jl. Perjuangan Keras No. 45, Bandung',
            harga: 1200000,
            fasilitas: ['WiFi', 'Parkir Motor'],
            gambar: 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8aG91c2UlMjBleHRlcmlvcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
            durasi: 'Bulanan'
        },
        {
            id: 3,
            nama: 'Kost Campur Ceria Bersama',
            tipe: 'Campur',
            lokasi: 'Jl. Suka Damai Blok C1, Surabaya',
            harga: 900000,
            fasilitas: ['Dapur Bersama', 'WiFi'],
            gambar: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8aG91c2UlMjBleHRlcmlvcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
            durasi: 'Harian'
        },
        {
            id: 4,
            nama: 'Kost Putri Anggun Menawan',
            tipe: 'Putri',
            lokasi: 'Gg. Pelangi Indah No. 1, Yogyakarta',
            harga: 1800000,
            fasilitas: ['AC', 'WiFi', 'Kamar Mandi Dalam', 'TV Kabel'],
            gambar: 'https://images.unsplash.com/photo-1598228723793-52759bba239c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fGhvdXNlJTIwZXh0ZXJpb3J8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
            durasi: 'Bulanan'
        },
         {
            id: 5,
            nama: 'Wisma Putra Perkasa',
            tipe: 'Putra',
            lokasi: 'Jl. Sudirman Kav. 22, Jakarta Pusat',
            harga: 2500000,
            fasilitas: ['AC', 'WiFi', 'Kamar Mandi Dalam', 'Parkir Mobil', 'Gym Mini'],
            gambar: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGhvdXNlJTIwZXh0ZXJpb3J8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
            durasi: 'Tahunan'
        },
        {
            id: 6,
            nama: 'Kost Campur Adem Ayem',
            tipe: 'Campur',
            lokasi: 'Jl. Tentram Selalu No. 8, Semarang',
            harga: 1000000,
            fasilitas: ['WiFi', 'Dapur Bersama', 'Ruang Santai'],
            gambar: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8aG91c2UlMjBleHRlcmlvcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
            durasi: 'Bulanan'
        }
    ];

    const hasilPencarianElement = document.getElementById('hasilPencarianKost');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const searchForm = document.getElementById('searchForm');

    function formatRupiah(angka) {
        return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(angka);
    }

    function buatKartuKost(kost) {
        let tipeBadgeClass = '';
        switch (kost.tipe.toLowerCase()) {
            case 'putra': tipeBadgeClass = 'badge-putra'; break;
            case 'putri': tipeBadgeClass = 'badge-putri'; break;
            case 'campur': tipeBadgeClass = 'badge-campur'; break;
        }

        const fasilitasBadges = kost.fasilitas.map(f => `<span class="badge badge-facility">${f}</span>`).join('');

        return `
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="kost-card">
                    <div class="img-container">
                        <img src="${kost.gambar}" alt="${kost.nama}">
                    </div>
                    <div class="card-body">
                        <span class="badge kost-type-badge ${tipeBadgeClass}">${kost.tipe}</span>
                        <h5 class="kost-name">${kost.nama}</h5>
                        <p class="kost-location"><i class="fas fa-map-marker-alt"></i> ${kost.lokasi}</p>
                        <div class="kost-facilities">
                            ${fasilitasBadges}
                        </div>
                        <p class="kost-price">${formatRupiah(kost.harga)} <span class="period">/ ${kost.durasi}</span></p>
                        <a href="#" class="btn btn-detail btn-block">Lihat Detail</a>
                    </div>
                </div>
            </div>
        `;
    }

    function tampilkanKost(dataKost) {
        hasilPencarianElement.innerHTML = ''; // Kosongkan hasil sebelumnya
        if (dataKost.length === 0) {
            hasilPencarianElement.innerHTML = '<div class="col-12 text-center"><p>Maaf, kost tidak ditemukan dengan kriteria tersebut.</p></div>';
            return;
        }
        dataKost.forEach(kost => {
            hasilPencarianElement.innerHTML += buatKartuKost(kost);
        });
    }

    // Fungsi filter (sangat dasar)
    function filterKost() {
        loadingIndicator.style.display = 'none'; // Sembunyikan pesan awal
        let filteredData = allKostData;

        const lokasiQuery = document.getElementById('lokasiKost').value.toLowerCase();
        const tipeKostQuery = document.getElementById('tipeKost').value;
        const hargaMaxQuery = parseFloat(document.getElementById('hargaKost').value);

        // Filter berdasarkan lokasi (pencocokan substring sederhana)
        if (lokasiQuery) {
            filteredData = filteredData.filter(k => k.lokasi.toLowerCase().includes(lokasiQuery) || k.nama.toLowerCase().includes(lokasiQuery));
        }

        // Filter berdasarkan tipe kost
        if (tipeKostQuery) {
            filteredData = filteredData.filter(k => k.tipe === tipeKostQuery);
        }

        // Filter berdasarkan harga maksimum
        if (!isNaN(hargaMaxQuery) && hargaMaxQuery > 0) {
            filteredData = filteredData.filter(k => k.harga <= hargaMaxQuery);
        }

        // Filter lanjutan (contoh)
        const fasilitasAC = document.getElementById('fasilitasAC').checked;
        if (fasilitasAC) {
            filteredData = filteredData.filter(k => k.fasilitas.includes('AC'));
        }
        const fasilitasWiFi = document.getElementById('fasilitasWiFi').checked;
        if (fasilitasWiFi) {
            filteredData = filteredData.filter(k => k.fasilitas.includes('WiFi'));
        }
        const fasilitasKM = document.getElementById('fasilitasKM').checked;
        if (fasilitasKM) {
            filteredData = filteredData.filter(k => k.fasilitas.includes('Kamar Mandi Dalam'));
        }

        const durasiSewaQuery = document.getElementById('durasiSewa').value;
        if(durasiSewaQuery){
            filteredData = filteredData.filter(k => k.durasi === durasiSewaQuery);
        }

        // Urutkan (contoh)
        const urutkanQuery = document.getElementById('urutkan').value;
        if (urutkanQuery === 'harga-terendah') {
            filteredData.sort((a, b) => a.harga - b.harga);
        } else if (urutkanQuery === 'harga-tertinggi') {
            filteredData.sort((a, b) => b.harga - a.harga);
        }
        // (Implementasi urutan "relevansi" dan "terbaru" memerlukan data/logika backend)


        tampilkanKost(filteredData);
    }

    // Event listener untuk form pencarian
    searchForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Mencegah submit form standar
        filterKost();
    });

    // Event listener untuk filter lanjutan jika ada perubahan
    document.getElementById('collapseFilters').addEventListener('change', filterKost);


    // (Opsional) Tampilkan semua kost saat halaman pertama kali dimuat, atau biarkan kosong hingga ada pencarian
    // tampilkanKost(allKostData); // Uncomment jika ingin menampilkan semua saat load
    // Atau, biarkan loadingIndicator yang tampil.
});