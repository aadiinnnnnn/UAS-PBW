// profil-owner.js
document.addEventListener('DOMContentLoaded', function() {
    const tahunElement = document.getElementById('tahunSekarangProfilPage');
    if (tahunElement) {
        tahunElement.textContent = new Date().getFullYear();
    }

    const fotoProfilInput = document.getElementById('fotoProfilPage');
    const profileImagePreview = document.getElementById('profileImagePreviewPage');
    const defaultProfileImage = 'https://via.placeholder.com/150/367A83/FFFFFF?text=Foto';

    if (fotoProfilInput) {
        fotoProfilInput.addEventListener('change', function(event) {
            const inputFile = event.target;
            const fileLabel = $(this).next('.custom-file-label');

            if (inputFile.files && inputFile.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    if (profileImagePreview) profileImagePreview.src = e.target.result;
                }
                reader.readAsDataURL(inputFile.files[0]);
                if (fileLabel) fileLabel.html(inputFile.files[0].name);
            } else {
                if (profileImagePreview) profileImagePreview.src = defaultProfileImage;
                if (fileLabel) fileLabel.html('Pilih foto...');
            }
        });
    }

    const formProfil = document.getElementById('formProfilOwnerPage');
    if (formProfil) {
        formProfil.addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(formProfil);
            console.log("Data Profil Owner:");
            for (let [key, value] of formData.entries()) {
                console.log(`${key}: ${value instanceof File ? value.name : value}`);
            }
            alert('Perubahan profil disimulasikan untuk disimpan! Cek console.');
            // fetch('/api/owner/update-profile', { method: 'POST', body: formData }) ...
        });
    }

    // Load existing profile data from backend (example)
    // fetch('/api/owner/get-profile')
    // .then(response => response.json())
    // .then(data => {
    //     if(document.getElementById('namaLengkapProfil')) document.getElementById('namaLengkapProfil').value = data.namaLengkap || '';
    //     if(document.getElementById('emailProfilPage')) document.getElementById('emailProfilPage').value = data.email || '';
    //     if(document.getElementById('nomorTeleponProfil')) document.getElementById('nomorTeleponProfil').value = data.nomorTelepon || '';
    //     if(document.getElementById('alamatProfilPage')) document.getElementById('alamatProfilPage').value = data.alamat || '';
    //     if(profileImagePreview && data.urlFotoProfil) profileImagePreview.src = data.urlFotoProfil;
    // })
    // .catch(err => console.error("Gagal memuat data profil:", err));
});