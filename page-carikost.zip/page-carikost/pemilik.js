// dashboard-owner.js
document.addEventListener('DOMContentLoaded', function() {
    const tahunElement = document.getElementById('tahunSekarangDashboard');
    if (tahunElement) {
        tahunElement.textContent = new Date().getFullYear();
    }

    const welcomeMsg = document.getElementById('welcomeMessageDashboard');
    if (welcomeMsg) {
        // Ganti dengan nama pemilik dari data sesi/login backend
        welcomeMsg.textContent = 'Selamat Datang, Pemilik Terhormat!';
    }

    // Placeholder untuk data dinamis (nantinya dari API)
    const kostAktifEl = document.getElementById('totalKostAktifDashboard');
    if (kostAktifEl) kostAktifEl.textContent = '3'; // Contoh

    const kamarTersediaEl = document.getElementById('totalKamarTersediaDashboard');
    if (kamarTersediaEl) kamarTersediaEl.textContent = '12'; // Contoh

    const pesanBaruEl = document.getElementById('pesanBaruDashboard');
    if (pesanBaruEl) pesanBaruEl.textContent = '2'; // Contoh

    // Smooth scroll untuk link internal di halaman ini (jika ada yang belum otomatis oleh Bootstrap)
    document.querySelectorAll('#navbarNavOwnerDashboard a.nav-link[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                e.preventDefault();
                const headerOffset = document.querySelector('.header-custom.sticky-top')?.offsetHeight || 70;
                const elementPosition = targetElement.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: "smooth"
                });
            }
        });
    });

    // Bootstrap Scrollspy akan otomatis bekerja jika atribut data di HTML sudah benar.
    // Jika ada konten yang dimuat dinamis yang mengubah tinggi section, Anda mungkin perlu:
    // $(document.body).scrollspy('refresh');
});